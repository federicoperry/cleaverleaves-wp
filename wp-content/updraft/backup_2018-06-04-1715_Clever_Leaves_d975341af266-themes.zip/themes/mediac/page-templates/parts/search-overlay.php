<div class="toggle-overlay-container">
		<div class="search-box"><?php mediac_fnc_categories_searchform() ?></div>
		<div class="dropdown-toggle-button" data-target=".toggle-overlay-container"></div>
</div>