<?php
/**
 * The template for displaying a "No posts found" message
 *
 * @package WpOpal
 * @subpackage Mediac
 * @since Mediac 1.0
 */
