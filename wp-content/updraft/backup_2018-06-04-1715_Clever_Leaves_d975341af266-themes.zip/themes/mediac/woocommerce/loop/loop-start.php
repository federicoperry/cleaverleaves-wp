<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version       3.3.1
 */
?>
<div class="products products-<?php if ( isset($_GET['display']) && $_GET['display'] == 'list' ) { ?>list<?php }else{ ?>grid<?php } ?>"><div class="row row-products">