
<?php 

if ( ! is_active_sidebar( 'newsletter' ) ) {
	return;
}
?>
<section id="opal-newsletter" class="opal-newsletter">
	<div class="container">
		<div>
			<?php dynamic_sidebar( 'newsletter' ); ?>
		</div>
	</div>	
</section>	
 