<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Settings_Tab' );


	class TribeSettingsTab extends Tribe__Settings_Tab {

	}
