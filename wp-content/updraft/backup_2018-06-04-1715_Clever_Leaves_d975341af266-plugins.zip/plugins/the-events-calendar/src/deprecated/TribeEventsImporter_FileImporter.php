<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Importer__File_Importer' );


	abstract class TribeEventsImporter_FileImporter extends Tribe__Events__Importer__File_Importer {

	}